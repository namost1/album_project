import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs/promises'

const app = express()
app.use(express.json())

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

app.use(express.static(path.join(__dirname, 'public')))

const dataFilePath = path.join(__dirname, 'data', 'albums.json')

let albums = []

async function loadAlbums() {
    try {
        const data = await fs.readFile(dataFilePath, 'utf-8')
        albums = JSON.parse(data)
    } catch (err) {
        console.error('Nem sikerült betölteni az adatokat:', err)
        albums = []
    }
}

async function saveAlbums() {
    try {
        await fs.writeFile(dataFilePath, JSON.stringify(albums, null, 2))
    } catch (err) {
        console.error('Nem sikerült menteni az adatokat:', err)
    }
}

await loadAlbums()

app.get('/albums', (req, res) => {
    res.status(200).json(albums)
})

app.get('/albums/:id', (req, res) => {
    const album = albums.find(a => a.id === parseInt(req.params.id))
    if (!album) {
        return res.status(404).json({ message: "Album nem található" })
    }
    res.status(200).json(album)
})

app.post('/albums', async (req, res) => {
    const { zenekar, cim, ev, mufaj } = req.body
    if (!zenekar || !cim || !ev || !mufaj) {
        return res.status(400).json({ message: "Hiányzó adatok" })
    }

    const ujAlbum = {
        id: albums.length > 0 ? albums[albums.length - 1].id + 1 : 1,
        zenekar,
        cim,
        ev,
        mufaj
    }
    albums.push(ujAlbum)
    await saveAlbums()

    res.status(201).json(ujAlbum)
})

app.put('/albums/:id', async (req, res) => {
    const albumIndex = albums.findIndex(a => a.id === parseInt(req.params.id))
    if (albumIndex === -1) {
        return res.status(404).json({ message: "Album nem található" })
    }

    const { zenekar, cim, ev, mufaj } = req.body
    if (zenekar) albums[albumIndex].zenekar = zenekar
    if (cim) albums[albumIndex].cim = cim
    if (ev) albums[albumIndex].ev = ev
    if (mufaj) albums[albumIndex].mufaj = mufaj

    await saveAlbums()
    res.status(200).json(albums[albumIndex])
})

app.delete('/albums/:id', async (req, res) => {
    const albumIndex = albums.findIndex(a => a.id === parseInt(req.params.id))
    if (albumIndex === -1) {
        return res.status(404).json({ message: "Album nem található" })
    }

    albums.splice(albumIndex, 1)
    await saveAlbums()
    res.status(200).json({ message: "Album törölve!" })
})

app.use((err, req, res, next) => {
    console.error(err)
    res.status(500).json({ message: `Szerverhiba: ${err.message}` })
})

const PORT = 3000
app.listen(PORT, () => {
    console.log(`Szerver fut a ${PORT}-es porton`)
})
