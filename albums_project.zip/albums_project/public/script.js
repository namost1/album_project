function fetchAlbums() {
    fetch('/albums')
        .then(response => response.json())
        .then(data => {
            const albumokLista = document.getElementById('albumok-lista')
            albumokLista.innerHTML = ''
            data.forEach(album => {
                const li = document.createElement('li')
                li.innerHTML = `
                    <div><strong>${album.zenekar}</strong> - ${album.cim} (${album.ev}) [${album.mufaj}]</div>
                    <div>
                        <button onclick="editAlbum(${album.id})">Szerkesztés</button>
                        <button onclick="deleteAlbum(${album.id})">Törlés</button>
                    </div>
                `
                albumokLista.appendChild(li)
            })
        })
        .catch(error => {
            alert('Hiba történt az albumok lekérésekor')
        })
}

document.getElementById('add-album-form').addEventListener('submit', function(event) {
    event.preventDefault()
    const zenekar = document.getElementById('zenekar').value
    const cim = document.getElementById('cim').value
    const ev = document.getElementById('ev').value
    const mufaj = document.getElementById('mufaj').value

    fetch('/albums', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ zenekar, cim, ev, mufaj })
    })
    .then(response => response.json())
    .then(data => {
        alert('Album hozzáadva!')
        fetchAlbums()
    })
    .catch(error => {
        alert('Hiba történt az album hozzáadásakor')
    })
})

function deleteAlbum(id) {
    if (confirm("Biztosan törölni szeretnéd ezt az albumot?")) {
        fetch(`/albums/${id}`, {
            method: 'DELETE',
        })
        .then(response => response.json())
        .then(data => {
            alert('Album törölve!')
            fetchAlbums()
        })
        .catch(error => {
            alert('Hiba történt az album törlésénél')
        })
    }
}

function editAlbum(id) {
    const zenekar = prompt("Új zenekar neve:")
    const cim = prompt("Új album címe:")
    const ev = prompt("Új kiadás éve:")
    const mufaj = prompt("Új műfaj:")

    if (zenekar && cim && ev && mufaj) {
        fetch(`/albums/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ zenekar, cim, ev, mufaj })
        })
        .then(response => response.json())
        .then(data => {
            alert('Album módosítva!')
            fetchAlbums()
        })
        .catch(error => {
            alert('Hiba történt az album módosításakor')
        })
    }
}

fetchAlbums()
